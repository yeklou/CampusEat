#2.5 QUESTION 1 adding new row into Restaurant table

#good data
INSERT INTO `restaurant` VALUES
 (104,
 '5357 Adrianna Shoal Suite 418\nEnochside, 
 OH 46739-1915','hope Ltd','
 9am -5pm
 ','http://mcd.com/')
 
 
 #bad data
 INSERT INTO `restaurant` VALUES
 (88,
 '5357 Adrianna Shoal Suite 418\nEnochside, 
 OH 46739-1915','Rath Ltd','
 9am -5pm
 ','http://mcd.com/')
 
 
 
 #2.5 QUESTION 2 CREATE FUNCTION that returns the Driver_ID given Driver_name
 
 DELIMITER //

CREATE FUNCTION get_driver_id
(
   driver_name_param VARCHAR(50)
)
RETURNS INT
DETERMINISTIC READS SQL DATA
BEGIN
  DECLARE driver_id_var INT;
  
  SELECT driver_id
  INTO driver_id_var
  FROM driver
  WHERE driver_name = driver_name_param;
  
  RETURN(driver_id_var);
END//
#TEST get_driver_id
SELECT license_number,rating
FROM driver
WHERE driver_id = get_driver_id('INSERT NAME');




 #2.5 QUESTION 3 CREATE FUNCTION that returns the Restaurant_ID given Restaurant_name
 
 DROP FUNCTION get_restaurant_id

DELIMITER //

CREATE FUNCTION get_restaurant_id
(
   restaurant_name_param VARCHAR(50)
)
RETURNS INT
DETERMINISTIC READS SQL DATA
BEGIN
  DECLARE restaurant_id_var INT;
  
  SELECT restaurant_id
  INTO restaurant_id_var
  FROM restaurant
  WHERE restaurant_name = restaurant_name_param;
  
  RETURN(restaurant_id_var);
END//


#Test get_resturant_id
SELECT 
    schedule, website
FROM
    restaurant
WHERE
    restaurant_id = GET_RESTAURANT_ID('Berge Inc');


 #2.5 QUESTION 4 CREATE stored Procedure for avg ratings for restaurants
 
 DROP FUNCTION get_average_restaurant_rating
DELIMITER //
CREATE FUNCTION get_average_restaurant_rating
(
   restaurant_rating_param INT
)
RETURNS DECIMAL(9,2)
DETERMINISTIC READS SQL DATA
BEGIN
  DECLARE average_restaurant_rating_var DECIMAL(9,2);
  
  SELECT AVG(restaurant_rating)
  INTO average_restaurant_rating_var
  FROM rating
  WHERE restaurant_rating = restaurant_rating_param;
  
  RETURN average_restaurant_rating_var;
END//
#TEST get_average_restaurant_rating
SELECT AVG(get_average_restaurant_rating(restaurant_rating)) AS rating
FROM rating
WHERE restaurant_id IS NULL

 #2.5 QUESTION 5 CREATE stored Procedure for avg ratings for drivers
 
 DROP FUNCTION get_average_driver_rating
DELIMITER //
CREATE FUNCTION get_average_driver_rating
(
   driver_rating_param INT
)
RETURNS DECIMAL(9,2)
DETERMINISTIC READS SQL DATA
BEGIN
  DECLARE average_driver_rating_var DECIMAL(9,2);
  
  SELECT AVG(rating)
  INTO average_driver_rating_var
  FROM driver
  WHERE rating = driver_rating_param;
  
  RETURN average_driver_rating_var;
END//

#TEST get_average_driver_rating
SELECT get_average_driver_rating(rating) AS rating, date_hired
FROM driver
WHERE driver_id = 3













