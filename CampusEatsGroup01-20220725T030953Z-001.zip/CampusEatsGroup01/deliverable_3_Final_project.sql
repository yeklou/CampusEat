/* Creating a stored procedure to calculate ratings */

DELIMITER //
CREATE PROCEDURE restaurant_rating()
BEGIN
	SELECT restaurant_name, AVG(restaurant_rating) AS avg_rating
    FROM rating AS r
    INNER JOIN restaurant AS rs
		ON r.restaurant_id = rs.restaurant_id
	GROUP BY restaurant_name
    ORDER BY AVG(restaurant_rating) DESC;
END //
DELIMITER ;

CALL restaurant_rating();

/* creating an Index for report type queries */

CREATE INDEX rating_restaurant_rating_ix
ON rating (restaurant_id, restaurant_rating DESC);

DROP INDEX restaurant_order_ix ON `Campus_Eats_Fall2020`.ORDER;
CREATE UNIQUE INDEX restaurant_order_ix
ON `Campus_Eats_Fall2020`.ORDER (ORDER_ID, PERSON_ID, DELIVERY_ID, LOCATION_ID, DRIVER_ID, RESTAURANT_ID DESC);

SELECT * FROM `Campus_Eats_Fall2020`.ORDER;

/* Creating an advanced view using Window functions and Common Table Expressions (CTE) */

CREATE OR REPLACE VIEW driver_details AS

WITH delivery_details AS (
SELECT delivery_id, driver_id, delivery_time, vehicle_id
FROM delivery
)
SELECT
driver.driver_id,
driver.rating AS driver_rating, date_hired, vehicle_id, delivery_time,
COUNT(driver.driver_id) OVER(PARTITION BY driver.driver_id,date_hired,vehicle_id ORDER BY driver.rating DESC) AS count
FROM DRIVER AS driver
INNER JOIN delivery_details
ON delivery_details.driver_id = driver.driver_id;

SELECT * FROM driver_details;

/* Creating an advanced view using Conditional statements, Group by and sort */

CREATE OR REPLACE VIEW restaurant_ratings AS
SELECT 
rs.restaurant_name, 
r.restaurant_rating,
CASE r.restaurant_rating WHEN 1 THEN 'VERY POOR'
	WHEN 2 THEN 'POOR'
	WHEN 3 THEN 'AVERAGE'
	WHEN 4 THEN 'GOOD'
	WHEN 5 THEN 'EXCELLENT'
	ELSE 'NOT AVAILABLE'
	END
FROM restaurant AS rs
LEFT JOIN rating AS r
	ON r.restaurant_id = rs.restaurant_id
GROUP BY rs.restaurant_name, r.restaurant_rating
ORDER BY r.restaurant_rating DESC, rs.restaurant_name;

SELECT * FROM restaurant_ratings;

/* Creating an advanced view using nested queries and summary functions */

CREATE OR REPLACE VIEW restaurant_price_rating AS
SELECT 
rs.restaurant_name, 
r.restaurant_rating,
ROUND(SUM(ordr.total_price),2) AS sum_total_price
FROM restaurant AS rs
INNER JOIN `Campus_Eats_Fall2020`.ORDER AS ordr
	ON rs.restaurant_id = ordr.restaurant_id
LEFT JOIN rating AS r
	ON r.restaurant_id = rs.restaurant_id
WHERE EXISTS (SELECT * FROM location AS l
	WHERE l.location_id = ordr.location_id)
GROUP BY rs.restaurant_name, r.restaurant_rating
HAVING sum_total_price > 5
ORDER BY restaurant_rating DESC, sum_total_price;

SELECT * FROM restaurant_price_rating; 





