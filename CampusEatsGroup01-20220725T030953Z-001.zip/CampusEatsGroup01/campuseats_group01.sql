/*CREATE NEW RATING TABLE*/
CREATE TABLE rating (
  `rating_id` int NOT NULL AUTO_INCREMENT,
  `driver_id` int DEFAULT NULL,
  `driver_rating` smallint DEFAULT NULL,
  `driver_comments` varchar(255) DEFAULT NULL,
  `restaurant_id` int DEFAULT NULL,
  `restaurant_rating` smallint DEFAULT NULL,  
  `restaurant_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rating_id`),
  CONSTRAINT `fk_rating_restaurant_id` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`restaurant_id`),
  CONSTRAINT `fk_rating_delivery_id` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`),
  CONSTRAINT `rating_chk_01` CHECK ((`driver_rating` between 0 and 5)),
    CONSTRAINT `rating_chk_02` CHECK ((`restaurant_rating` between 0 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;

 /*INSERT DUMMY GENERATED VALUES FOR RATING. COMMENTS FIELD CURRENTLY BLANK AS GENERATE OPTION NOT AVAILABLE*/
 /*THE DRIVER ID AND RESTAURANT ID ARE BASED ON ORDER ID AND WILL BE UPDATED POST THIS*/
 INSERT INTO `RATING` (`RATING_ID`,`DRIVER_RATING`,`RESTAURANT_RATING`)
VALUES
  (101,3,1),
  (102,1,3),
  (103,4,3),
  (104,4,1),
  (105,5,5),
  (106,3,1),
  (107,2,5),
  (108,3,5),
  (109,3,0),
  (110,5,0),
  (111,0,5),
  (112,1,0),
  (113,3,1),
  (114,2,3),
  (115,2,1),
  (116,0,1),
  (117,2,4),
  (118,1,3),
  (119,4,4),
  (120,2,2),
  (121,5,2),
  (122,1,1),
  (123,1,0),
  (124,0,0),
  (125,3,1),
  (126,5,2),
  (127,2,3),
  (128,1,2),
  (129,5,2),
  (130,4,3),
  (131,5,5),
  (132,0,1),
  (133,5,4),
  (134,1,3),
  (135,4,1),
  (136,1,1),
  (137,2,4),
  (138,2,2),
  (139,1,1),
  (140,1,3),
  (141,2,0),
  (142,2,0),
  (143,3,2),
  (144,5,2),
  (145,0,0),
  (146,2,2),
  (147,1,2),
  (148,5,1),
  (149,4,2);
INSERT INTO `RATING` (`RATING_ID`,`DRIVER_RATING`,`RESTAURANT_RATING`)
VALUES
  (150,1,3),
  (151,1,2),
  (152,0,1),
  (153,4,5),
  (154,5,4),
  (155,0,4),
  (156,3,2),
  (157,2,3),
  (158,3,4),
  (159,2,4),
  (160,4,5),
  (161,3,2),
  (162,5,1),
  (163,4,4),
  (164,5,2),
  (165,2,1),
  (166,1,4),
  (167,5,2),
  (168,0,1),
  (169,0,1),
  (170,4,3),
  (171,0,4),
  (172,3,3),
  (173,3,5),
  (174,1,2),
  (175,4,5),
  (176,2,0),
  (177,1,1),
  (178,3,5),
  (179,2,4),
  (180,2,2),
  (181,1,1),
  (182,3,2),
  (183,5,5),
  (184,2,3),
  (185,2,3),
  (186,4,0),
  (187,1,4),
  (188,1,2),
  (189,1,2),
  (190,3,2),
  (191,5,4),
  (192,2,4),
  (193,2,2),
  (194,3,4),
  (195,4,2),
  (196,5,2),
  (197,1,4),
  (198,1,2),
  (199,4,2);
INSERT INTO `RATING` (`RATING_ID`,`DRIVER_RATING`,`RESTAURANT_RATING`)
VALUES
  (200,1,1);
  INSERT INTO `RATING` (`RATING_ID`,`DRIVER_RATING`,`RESTAURANT_RATING`)
VALUES
  (201,5,5);

/*ADD RATING ID TO ORDER TABLE*/
ALTER TABLE campus_eats_fall2020.order
ADD rating_id INT ,
add CONSTRAINT `fk_Rest_rating_id` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`)
 ; 
 /*GENERATE TEST DATA CONTINUES: ORDER TABLE UPDATED WITH RATING ID GENERATED ABOVE*/
UPDATE  campus_eats_fall2020.`ORDER`
SET rating_id = order_id + 100
where order_id < 200 ; /*if safe mode is on*/

/*USING ORDER TABLE, UPDATE DRIVER_ID AND RESTAURANT_ID*/
UPDATE 
	campus_eats_fall2020.RATING TGT,
	campus_eats_fall2020.`ORDER` SRC
SET TGT.`driver_id`  = SRC.`driver_id` ,
TGT.`restaurant_id`  = SRC.`restaurant_id` 
WHERE TGT.RATING_ID = SRC.RATING_ID ;


/*SP TO UPDATE THESE COLUMNS USING AVERAGE VALUE ACROSS ALL RATINGS*/
ALTER TABLE campus_eats_fall2020.restaurant 
ADD RATING FLOAT CHECK(RATING BETWEEN 0.00 AND 5.00) ; 

UPDATE campus_eats_fall2020.restaurant TGT,
	(SELECT RESTAURANT_ID, AVG(CAST(restaurant_RATING AS FLOAT)) RATING 
    FROM campus_eats_fall2020.RATING GROUP BY RESTAURANT_ID) SRC
SET TGT.RATING = SRC.RATING
WHERE TGT.RESTAURANT_ID = SRC.RESTAURANT_ID;

/*SP TO UPDATE THESE COLUMNS USING AVERAGE VALUE ACROSS ALL RATINGS*/
ALTER TABLE campus_eats_fall2020.DRIVER DROP RATING;
ALTER TABLE campus_eats_fall2020.DRIVER 
ADD RATING FLOAT CHECK(RATING BETWEEN 0.00 AND 5.00) ; 

UPDATE campus_eats_fall2020.DRIVER TGT,
	(SELECT DRIVER_ID, AVG(DRIVER_RATING) RATING 
    FROM campus_eats_fall2020.RATING GROUP BY DRIVER_ID) SRC
SET TGT.RATING = SRC.RATING
WHERE TGT.DRIVER_ID = SRC.DRIVER_ID
AND TGT.STUDENT_ID < 200; /*TO OVERRIDE SAFE MODE SETTINGS. PK = STUDENT ID*/

