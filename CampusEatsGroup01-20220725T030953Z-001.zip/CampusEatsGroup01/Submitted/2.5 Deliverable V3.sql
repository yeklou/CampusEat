#2.5 QUESTION 1 adding new row into Restaurant table

#good data
INSERT INTO campus_eats_fall2020.`restaurant` 
(restaurant_id, location, restaurant_name, schedule, website, RATING)
VALUES
 (104,
 '5357 Adrianna Shoal Suite 418\nEnochside, 
 OH 46739-1915','hope Ltd','
 9am -5pm
 ','http://mcd.com/',5);
 
 select * from campus_eats_fall2020.`restaurant` where restaurant_id = 104; 
 
 
 #bad data
INSERT INTO campus_eats_fall2020.`restaurant` 
(restaurant_id, location, restaurant_name, schedule, website, RATING)
VALUES
 (88, '5357 Adrianna Shoal Suite 418\nEnochside,  OH 46739-1915','Rath Ltd',' 9am -5pm ','http://mcd.com/',6);
 #bad data
INSERT INTO campus_eats_fall2020.`restaurant` 
(restaurant_id, location, restaurant_name, schedule, website, RATING)
VALUES
 (88, '5357 Adrianna Shoal Suite 418\nEnochside,  OH 46739-1915','Rath Ltd',' 9am -5pm ','http://mcd.com/',5);
 
 
 
#2.5 QUESTION 2 CREATE FUNCTION that returns the Driver_ID given Driver_name
DROP FUNCTION IF EXISTS campus_eats_fall2020.get_driver_id;

DELIMITER //
CREATE FUNCTION campus_eats_fall2020.get_driver_id(  person_name_param VARCHAR(300))
RETURNS INT
DETERMINISTIC READS SQL DATA
BEGIN
  DECLARE Driver_ID_Var INT;
  
		  SELECT Driver_id
		  INTO Driver_ID_Var
		  FROM campus_eats_fall2020.Driver dr
		  inner join campus_eats_fall2020.student st
			on st.student_id = dr.student_id
		  inner join campus_eats_fall2020.person per
			on per.person_id = st.person_id
		  WHERE person_name = person_name_param;
  
  RETURN(Driver_ID_Var);
END//

#Test
select campus_eats_fall2020.get_driver_id('Stone Kshlerin') ;


 #2.5 QUESTION 3 CREATE FUNCTION that returns the Restaurant_ID given Restaurant_name

DROP FUNCTION IF EXISTS campus_eats_fall2020.get_restaurant_id;

DELIMITER //
CREATE FUNCTION campus_eats_fall2020.get_restaurant_id( restaurant_name_param VARCHAR(75))
RETURNS INT
DETERMINISTIC READS SQL DATA
BEGIN
  DECLARE restaurant_id_var INT;
  
  SELECT restaurant_id
  INTO restaurant_id_var
  FROM campus_eats_fall2020.restaurant
  WHERE restaurant_name = restaurant_name_param;
  
  RETURN(restaurant_id_var);
END//

#Test get_resturant_id
select campus_eats_fall2020.GET_RESTAURANT_ID('Berge Inc');



 
 #2.5 QUESTION 4 CREATE stored Procedure for avg ratings for restaurants
 DROP procedure IF EXISTS campus_eats_fall2020.get_average_restaurant_rating;
DELIMITER //
CREATE procedure campus_eats_fall2020.get_average_restaurant_rating()
DETERMINISTIC READS SQL DATA
BEGIN
    
  SELECT AVG(restaurant_rating) Average_Restaurant_Rating
  FROM campus_eats_fall2020.Restaurant_rating;
  
END//
#TEST get_average_restaurant_rating
call campus_eats_fall2020.get_average_restaurant_rating();


 #2.5 QUESTION 5 CREATE stored Procedure for avg ratings for drivers
 DROP procedure IF EXISTS campus_eats_fall2020.get_average_driver_rating;
 
DELIMITER //
CREATE procedure campus_eats_fall2020.get_average_driver_rating(driver_id_param INT)
DETERMINISTIC READS SQL DATA
BEGIN
  
  SELECT AVG(driver_rating) Average_Driver_Rating
  FROM campus_eats_fall2020.driver_rating
  WHERE driver_id = driver_id_param;
  /*We can also select this directly from column Rating in table Driver as The column is Average of all ratings per driver*/
  
END//
call campus_eats_fall2020.get_average_driver_rating(2); 













