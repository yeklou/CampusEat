/*Rating is available as a single entity that is fully normalised into 2 tables. Driver_Rating and Restaurant_Rating*/
/*CREATE NEW RATING TABLES */
CREATE TABLE campus_eats_fall2020.Driver_Rating (
  `Driver_Rating_id` int NOT NULL AUTO_INCREMENT,
  `order_id` INT Not Null,
  `driver_id` int DEFAULT NULL,
  `driver_rating` smallint DEFAULT NULL,
  `driver_comments` varchar(255) DEFAULT NULLStep 02: ,
  PRIMARY KEY (`Driver_Rating_id`),
  CONSTRAINT `fk_DR_delivery_id` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`),
  CONSTRAINT `fk_DR_order_id` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`),
  CONSTRAINT `rating_chk_01` CHECK ((`driver_rating` between 0 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;

CREATE  TABLE campus_eats_fall2020.Restaurant_Rating (
  `Restaurant_rating_id` int NOT NULL AUTO_INCREMENT,
  `order_id` INT Not Null,
  `restaurant_id` int DEFAULT NULL,
  `restaurant_rating` smallint DEFAULT NULL,  
  `restaurant_comments` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Restaurant_rating_id`),
  CONSTRAINT `fk_RR_restaurant_id` FOREIGN KEY (`restaurant_id`) REFERENCES `restaurant` (`restaurant_id`),
  CONSTRAINT `fk_RR_order_id` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`),
    CONSTRAINT `rating_chk_02` CHECK ((`restaurant_rating` between 0 and 5))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;

/*INSERT DUMMY GENERATED VALUES FOR Restaurant_Rating. */
 /*THE Restaurant ID is BASED ON ORDER ID AND WILL BE UPDATED POST THIS*/
 INSERT INTO campus_eats_fall2020.`Restaurant_Rating` (`Restaurant_rating_id`,`order_id`,`restaurant_id`,`restaurant_rating`,`restaurant_comments`)
VALUES
(101,1,Null,0,'Bad')	,
(102,2,Null,1,'Pass')	,
(103,3,Null,2,'Average')	,
(104,4,Null,3,'Good for In and Out')	,
(105,5,Null,4,'for their prices it’s 100% worth it')	,
(106,6,Null,5,'my new favorite')	,
(107,7,Null,5,'Tapas is Stunning')	,
(108,8,Null,4,'very delectable')	,
(109,9,Null,4,'the food was amazing')	,
(110,10,Null,4,'mouthwatering')	,
(111,11,Null,4,'my new favorite')	,
(112,12,Null,5,'Excellent food. ')	,
(113,13,Null,4,'mouthwatering')	,
(114,14,Null,3,'Average')	,
(115,15,Null,5,'Excellent, unassuming and wonderful')	,
(116,16,Null,4,'my new favorite')	,
(117,17,Null,5,'Top notch food')	,
(118,18,Null,5,'Tapas is Stunning')	,
(119,19,Null,4,'mouthwatering')	,
(120,20,Null,1,'Not Great')	,
(121,21,Null,2,'Ok')	,
(122,22,Null,3,'Extremely Average')	,
(123,23,Null,4,'Outstanding meal')	,
(124,24,Null,5,'my new favorite')	,
(125,25,Null,5,'for their prices it’s 100% worth it')	,
(126,26,Null,4,'very delectable')	,
(127,27,Null,5,'Great variety and fine value tasting menu.')	,
(128,28,Null,4,'my new favorite')	,
(129,29,Null,4,'Menu is extensive and seasonal to a particularly high standard.')	,
(130,30,Null,5,'The food is absolutely amazing')	,
(131,31,Null,4,'my new favorite')	,
(132,32,Null,5,'my new favorite')	,
(133,33,Null,5,'Delicious high quality plates')	,
(134,34,Null,4,'mouthwatering')	,
(135,35,Null,3,'Barely edible')	,
(136,36,Null,5,'for their prices it’s 100% worth it')	,
(137,37,Null,0,'Not Edible')	,
(138,38,Null,5,'my new favorite')	,
(139,39,Null,5,'I enjoyed every single bite of the meal')	,
(140,40,Null,4,'Great variety and fine value tasting menu.')	,
(141,41,Null,4,'my new favorite')	,
(142,42,Null,5,'I enjoyed every single bite of the meal')	,
(143,43,Null,5,'This is my absolute favorite restaurant')	,
(144,44,Null,4,'The food is absolutely amazing')	,
(145,45,Null,3,'Good Packaging. Thats all')	,
(146,46,Null,5,'I enjoyed every single bite of the meal')	,
(147,47,Null,4,'mouthwatering')	,
(148,48,Null,3,'Average')	,
(149,49,Null,4,'for their prices it’s 100% worth it')	,
(150,50,Null,3,'Barely edible')	,
(151,51,Null,5,'Amaazing food! ')	,
(152,52,Null,4,'very delectable')	,
(153,53,Null,5,'Excellent food. Menu is extensive and seasonal to a particularly high standard.')	,
(154,54,Null,5,'The food is absolutely amazing')	,
(155,55,Null,2,'Average')	,
(156,56,Null,4,'I enjoyed every single bite of the meal')	,
(157,57,Null,2,'Ok')	,
(158,58,Null,5,'The food is absolutely amazing')	,
(159,59,Null,4,'for their prices it’s 100% worth it')	,
(160,60,Null,5,'Outstanding meal')	,
(161,61,Null,5,'Tacos are to die for')	,
(162,62,Null,4,'mouthwatering')	,
(163,63,Null,3,'Average')	,
(164,64,Null,4,'Excellent, unassuming and wonderful')	,
(165,65,Null,4,'Very tasty and well prepared')	,
(166,66,Null,5,'This is my absolute favorite restaurant')	,
(167,67,Null,4,'mouthwatering')	,
(168,68,Null,3,'Barely edible')	,
(169,69,Null,5,'Top notch food')	,
(170,70,Null,4,'Delicious high quality plates')	,
(171,71,Null,4,'very delectable')	,
(172,72,Null,5,'Excellent food. ')	,
(173,73,Null,0,'Extremely Over Spiced')	,
(174,74,Null,1,'Stale Food')	,
(175,75,Null,5,'Great variety and fine value tasting menu.')	,
(176,76,Null,5,'Top notch food')	,
(177,77,Null,4,'Tacos are to die for')	,
(178,78,Null,5,'Outstanding meal')	,
(179,79,Null,5,'Menu is extensive and seasonal to a particularly high standard.')	,
(180,80,Null,4,'Great variety and fine value tasting menu.')	,
(181,81,Null,5,'Amaazing food! ')	,
(182,82,Null,5,'This is my absolute favorite restaurant')	,
(183,83,Null,4,'Excellent, unassuming and wonderful')	,
(184,84,Null,3,'Average')	,
(185,85,Null,4,'Tacos are to die for')	,
(186,86,Null,4,'very delectable')	,
(187,87,Null,5,'the food was amazing')	,
(188,88,Null,4,'Excellent food. ')	,
(189,89,Null,5,'Amaazing food! ')	,
(190,90,Null,5,'Great variety and fine value tasting menu.')	,
(191,91,Null,4,'Very tasty and well prepared')	,
(192,92,Null,1,'Too Sweet')	,
(193,93,Null,2,'Average')	,
(194,94,Null,5,'Excellent food. ')	,
(195,95,Null,4,'very delectable')	,
(196,96,Null,5,'Excellent, unassuming and wonderful')	,
(197,97,Null,5,'This is my absolute favorite restaurant')	,
(198,98,Null,4,'Excellent food. ')	,
(199,99,Null,3,'Barely edible')	,
(200,100,Null,4,'the food was amazing')	,
(201,101,Null,4,'Very tasty and well prepared')	;


/*USING ORDER TABLE, UPDATE Restaurant_ID */
UPDATE 
	campus_eats_fall2020.Restaurant_Rating TGT,
	campus_eats_fall2020.`ORDER` SRC
SET TGT.`Restaurant_id`  = SRC.`Restaurant_id` 
WHERE TGT.ORDER_ID = SRC.ORDER_ID 
and Restaurant_Rating_id < 300; /*If Using Safe Mode*/


 /*INSERT DUMMY GENERATED VALUES FOR Driver RATING. */
 /*THE DRIVER ID is BASED ON ORDER ID AND WILL BE UPDATED POST THIS*/
 INSERT INTO campus_eats_fall2020.`Driver_Rating` (`Driver_Rating_id`,`order_id`,`driver_id`,`driver_rating`,`driver_comments`)
VALUES
 (101,1,Null,0,'Delayed Delivery')	,
(102,2,Null,1,'Very Late')	,
(103,3,Null,2,'Asked for Tip')	,
(104,4,Null,3,'OK')	,
(105,5,Null,4,' A very reliable operator ')	,
(106,6,Null,5,'Amazing service, to the door delivery and a smiling face with it!')	,
(107,7,Null,5,'The service was great.')	,
(108,8,Null,4,'On Time Delivery')	,
(109,9,Null,4,'quick delivery')	,
(110,10,Null,4,'Thank you')	,
(111,11,Null,4,'Polite driver. Very speedy!')	,
(112,12,Null,5,'Great professional service.')	,
(113,13,Null,4,'keep me informed at each stage and delivered securely and on time')	,
(114,14,Null,3,'Average')	,
(115,15,Null,5,'I got my order here ASAP.')	,
(116,16,Null,4,'fast and accurate')	,
(117,17,Null,5,'Great professional service.')	,
(118,18,Null,5,'arrived 15 minutes early and was very polite and courteous')	,
(119,19,Null,4,'Polite driver. Very speedy!')	,
(120,20,Null,1,'Wrong Address')	,
(121,21,Null,2,'Delayed delivery')	,
(122,22,Null,3,'OK')	,
(123,23,Null,4,'fast and accurate')	,
(124,24,Null,5,'Great professional service.')	,
(125,25,Null,5,'I got my order here ASAP.')	,
(126,26,Null,4,'Thank you')	,
(127,27,Null,5,'Great professional service.')	,
(128,28,Null,4,'keep me informed at each stage and delivered securely and on time')	,
(129,29,Null,4,'Polite driver. Very speedy!')	,
(130,30,Null,5,'The service was great.')	,
(131,31,Null,4,'Thank you')	,
(132,32,Null,5,'turned up within the promised time')	,
(133,33,Null,5,'Excellent, efficient service and a really friendly driver')	,
(134,34,Null,4,'quick delivery')	,
(135,35,Null,3,'Average')	,
(136,36,Null,5,'Amazing service, to the door delivery and a smiling face with it!')	,
(137,37,Null,0,'Very Bad')	,
(138,38,Null,5,'Excellent, efficient service and a really friendly driver')	,
(139,39,Null,5,'turned up within the promised time')	,
(140,40,Null,4,'Polite driver. Very speedy!')	,
(141,41,Null,4,'A totally brilliant service from start to finish')	,
(142,42,Null,5,'Excellent, efficient service and a really friendly driver')	,
(143,43,Null,5,'Amazing service, to the door delivery and a smiling face with it!')	,
(144,44,Null,4,'No complaints. I got everything I ordered')	,
(145,45,Null,3,'Average')	,
(146,46,Null,5,'Excellent, efficient service and a really friendly driver')	,
(147,47,Null,4,'keep me informed at each stage and delivered securely and on time')	,
(148,48,Null,3,'Average')	,
(149,49,Null,4,'No complaints. I got everything I ordered')	,
(150,50,Null,3,'Average')	,
(151,51,Null,5,'turned up within the promised time')	,
(152,52,Null,4,'A totally brilliant service from start to finish')	,
(153,53,Null,5,'delivered before our deadline. Very happy with the service')	,
(154,54,Null,5,'Amazing service, to the door delivery and a smiling face with it!')	,
(155,55,Null,2,'')	,
(156,56,Null,4,'Thank you')	,
(157,57,Null,2,'')	,
(158,58,Null,5,'delivered before our deadline. Very happy with the service')	,
(159,59,Null,4,'quick delivery')	,
(160,60,Null,5,'turned up within the promised time')	,
(161,61,Null,5,'delivered before our deadline. Very happy with the service')	,
(162,62,Null,4,'No complaints. I got everything I ordered')	,
(163,63,Null,3,'Average')	,
(164,64,Null,4,'No complaints. I got everything I ordered')	,
(165,65,Null,4,'Thank you')	,
(166,66,Null,5,'Amazing service, to the door delivery and a smiling face with it!')	,
(167,67,Null,4,'quick delivery')	,
(168,68,Null,3,'Average')	,
(169,69,Null,5,'I got my order here ASAP.')	,
(170,70,Null,4,'keep me informed at each stage and delivered securely and on time')	,
(171,71,Null,4,'fast and accurate')	,
(172,72,Null,5,'arrived 15 minutes early and was very polite and courteous')	,
(173,73,Null,0,'')	,
(174,74,Null,1,'Too Late')	,
(175,75,Null,5,'delivered before our deadline. Very happy with the service')	,
(176,76,Null,5,'Excellent service – fast and reasonable')	,
(177,77,Null,4,'quick delivery')	,
(178,78,Null,5,'arrived 15 minutes early and was very polite and courteous')	,
(179,79,Null,5,'Excellent service – fast and reasonable')	,
(180,80,Null,4,'Thank you')	,
(181,81,Null,5,'The service was great.')	,
(182,82,Null,5,'Excellent service – fast and reasonable')	,
(183,83,Null,4,'A totally brilliant service from start to finish')	,
(184,84,Null,3,'Average')	,
(185,85,Null,4,'Polite driver. Very speedy!')	,
(186,86,Null,4,'fast and accurate')	,
(187,87,Null,5,'arrived 15 minutes early and was very polite and courteous')	,
(188,88,Null,4,'keep me informed at each stage and delivered securely and on time')	,
(189,89,Null,5,'Excellent service – fast and reasonable')	,
(190,90,Null,5,'Excellent service – fast and reasonable')	,
(191,91,Null,4,'Thank you')	,
(192,92,Null,1,'Rude')	,
(193,93,Null,2,'')	,
(194,94,Null,5,'The service was great.')	,
(195,95,Null,4,'Polite driver. Very speedy!')	,
(196,96,Null,5,'Excellent service – fast and reasonable')	,
(197,97,Null,5,'Excellent service – fast and reasonable')	,
(198,98,Null,4,'keep me informed at each stage and delivered securely and on time')	,
(199,99,Null,3,'Average')	,
(200,100,Null,4,'Thank you')	,
(201,101,Null,4,'Polite driver. Very speedy!');

/*USING ORDER TABLE, UPDATE DRIVER_ID */
UPDATE 
	campus_eats_fall2020.Driver_Rating TGT,
	campus_eats_fall2020.`ORDER` SRC
SET TGT.`driver_id`  = SRC.`driver_id` 
WHERE TGT.ORDER_ID = SRC.ORDER_ID 
and Driver_Rating_id < 300; /*If Using Safe Mode*/


/*SP TO UPDATE THESE COLUMNS USING AVERAGE VALUE ACROSS ALL RATINGS*/
ALTER TABLE campus_eats_fall2020.restaurant 
ADD RATING FLOAT CHECK(RATING BETWEEN 0.00 AND 5.00) ; 

UPDATE campus_eats_fall2020.restaurant TGT,
	(SELECT RESTAURANT_ID, AVG(CAST(restaurant_RATING AS FLOAT)) RATING 
    FROM campus_eats_fall2020.Restaurant_Rating  GROUP BY RESTAURANT_ID) SRC
SET TGT.RATING = SRC.RATING
WHERE TGT.RESTAURANT_ID = SRC.RESTAURANT_ID;

UPDATE campus_eats_fall2020.DRIVER TGT,
	(SELECT DRIVER_ID, AVG(DRIVER_RATING) RATING 
    FROM campus_eats_fall2020.Driver_Rating  GROUP BY DRIVER_ID) SRC
SET TGT.RATING = SRC.RATING
WHERE TGT.DRIVER_ID = SRC.DRIVER_ID
AND  TGT.DRIVER_ID between 1 and 8; /*TO OVERRIDE SAFE MODE SETTINGS. */


