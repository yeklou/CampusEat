/* Creating a stored procedure to calculate ratings */

DELIMITER //
CREATE PROCEDURE campus_eats_fall2020.restaurant_rating()
BEGIN
	SELECT restaurant_name, AVG(restaurant_rating) AS avg_rating
    FROM campus_eats_fall2020.restaurant_rating AS r
    INNER JOIN campus_eats_fall2020.restaurant AS rs
		ON r.restaurant_id = rs.restaurant_id
	GROUP BY restaurant_name
    ORDER BY AVG(restaurant_rating) DESC;
END //
DELIMITER ;

CALL campus_eats_fall2020.restaurant_rating();

DELIMITER //
CREATE PROCEDURE campus_eats_fall2020.Driver_rating()
BEGIN
	SELECT Pe.person_name as Driver_Name, AVG(drr.Driver_rating) AS avg_rating
    FROM campus_eats_fall2020.driver_rating AS drr
    INNER JOIN campus_eats_fall2020.driver AS dr
		ON drr.driver_id = dr.driver_id
	inner join campus_eats_fall2020.student st
		on st.student_id = dr.student_id
	inner join campus_eats_fall2020.Person pe
		on pe.person_id = st.person_id
	GROUP BY Pe.person_name
    ORDER BY AVG(drr.Driver_rating) DESC;
END //
DELIMITER ;

CALL campus_eats_fall2020.Driver_rating();

/* creating an Index for report type queries */

CREATE INDEX rating_restaurant_rating_ix
ON campus_eats_fall2020.restaurant_rating (restaurant_id, restaurant_rating DESC);

CREATE UNIQUE INDEX restaurant_order_ix
ON `Campus_Eats_Fall2020`.ORDER (ORDER_ID, PERSON_ID, DELIVERY_ID, LOCATION_ID, DRIVER_ID, RESTAURANT_ID DESC);

SELECT * FROM `Campus_Eats_Fall2020`.ORDER;

/* Creating an advanced view using Window functions and Common Table Expressions (CTE) */

CREATE OR REPLACE VIEW campus_eats_fall2020.driver_details AS
WITH delivery_details AS (
SELECT delivery_id, driver_id, delivery_time, vehicle_id
FROM campus_eats_fall2020.delivery
)
SELECT
driver.driver_id,
driver.rating AS driver_rating, date_hired, vehicle_id, delivery_time,
COUNT(driver.driver_id) OVER(PARTITION BY driver.driver_id ORDER BY driver.rating DESC) AS Total_Deliveries_By_Driver
FROM campus_eats_fall2020.DRIVER AS driver
INNER JOIN delivery_details
ON delivery_details.driver_id = driver.driver_id;

SELECT * FROM campus_eats_fall2020.driver_details;

/* Creating an advanced view using Conditional statements, Group by and sort */

CREATE OR REPLACE VIEW campus_eats_fall2020.restaurant_ratings AS
SELECT 
rs.restaurant_name, 
r.restaurant_rating,
CASE WHEN r.restaurant_rating <= 1 THEN 'VERY POOR'
	WHEN  r.restaurant_rating <= 2 THEN 'POOR'
	WHEN  r.restaurant_rating <= 3 THEN 'AVERAGE'
	WHEN  r.restaurant_rating <= 4 THEN 'GOOD'
	WHEN  r.restaurant_rating <= 5 THEN 'EXCELLENT'
	ELSE 'NOT AVAILABLE'
	END Restaurant_Rating_Desc
FROM campus_eats_fall2020.restaurant AS rs
LEFT JOIN campus_eats_fall2020.restaurant_rating AS r
	ON r.restaurant_id = rs.restaurant_id
GROUP BY rs.restaurant_name, r.restaurant_rating
ORDER BY r.restaurant_rating DESC, rs.restaurant_name;

SELECT * FROM campus_eats_fall2020.restaurant_ratings;

/* Creating an advanced view using nested queries and summary functions */

CREATE OR REPLACE VIEW campus_eats_fall2020.restaurant_price_rating AS
SELECT 
rs.restaurant_name, 
r.restaurant_rating,
ROUND(AVG(ordr.total_price),2) AS Average_Cost
FROM campus_eats_fall2020.restaurant AS rs
INNER JOIN `Campus_Eats_Fall2020`.ORDER AS ordr
	ON rs.restaurant_id = ordr.restaurant_id
LEFT JOIN campus_eats_fall2020.Restaurant_rating AS r
	ON r.restaurant_id = rs.restaurant_id
WHERE EXISTS (SELECT * FROM campus_eats_fall2020.location AS l
	WHERE l.location_id = ordr.location_id)
GROUP BY rs.restaurant_name, r.restaurant_rating
HAVING Average_Cost > 5
ORDER BY restaurant_rating DESC, Average_Cost;

SELECT * FROM campus_eats_fall2020.restaurant_price_rating; 





